

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeDispserv
 */
@WebServlet("/EmployeeDispserv")
public class EmployeeDispserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeDispserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ResultSet rs=null;
		try 
		{
			PreparedStatement ps=null;
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/OOAD";
			Connection con=DriverManager.getConnection(URL,"root","admin");
			String eid=request.getParameter("eid");
			Integer e= Integer.parseInt(eid);
			ps=con.prepareStatement("select * from employee where eid=?");
			ps.setInt(1,e);
			rs=ps.executeQuery();
			while(rs.next())
			{
				out.println("Employee ID is : "+rs.getInt(1));
				out.println("<br />");
				out.println("Name is : "+rs.getString(2));
				out.println("<br />");
				out.println("Designation is : "+rs.getString(3));
				out.println("<br />");
				out.println("Grade is : "+rs.getInt(4));
				out.println("<br />");
				out.println("Mobile Number is : "+rs.getString(5));
				out.println("<br />");
				out.println("DOJ is : "+rs.getString(6));
				out.println("<br />");
				out.println("Qualification is : "+rs.getString(7));
				out.println("<br />");
				out.println("Attendance is : "+rs.getInt(8));
				out.println("<br />");
			}
			ps.close();
			out.println("Achievements Are : ");
			ps=con.prepareStatement("select * from achieve where eid=?");
			ps.setInt(1,e);
			rs=ps.executeQuery();
			while(rs.next())
			{
				out.println("<br />");
				out.println(rs.getString(2));
			}
			ps.close();
			con.close();
			out.println("<br />");
			out.println("<br />");
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
