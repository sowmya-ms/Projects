
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Loginserv
 */
@WebServlet("/Loginserv")
public class Loginserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PreparedStatement ps=null;
	ResultSet rs=null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Loginserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		ps=null;
		HttpSession ses=request.getSession();
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/OOAD";
			Connection con=DriverManager.getConnection(URL,"root","admin");
			String eid=request.getParameter("eid");
			int e=Integer.parseInt(eid);
			ses.setAttribute("eid", eid);
			String pwd=request.getParameter("password");
			ps=con.prepareStatement("select * from userdetails where eid=? and password=?");
			ps.setString(2, pwd);
			ps.setInt(1, e);
			rs=ps.executeQuery();
			boolean success=false;
			success=rs.next();
			if(success)
			{
				if(e<100)
				{
					RequestDispatcher rd=request.getRequestDispatcher("Admin.html");
					rd.forward(request,response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("EmployeeDisp.html");
					rd.forward(request,response);
				}
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("Login.html");
				rd.forward(request,response);
			}
			ps.close();
			con.close();
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
