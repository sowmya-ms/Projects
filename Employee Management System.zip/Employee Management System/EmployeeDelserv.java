

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeDelserv
 */
@WebServlet("/EmployeeDelserv")
public class EmployeeDelserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeDelserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try 
		{
			PreparedStatement ps=null;
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/OOAD";
			Connection con=DriverManager.getConnection(URL,"root","admin");
			String eid=request.getParameter("eid");
			Integer e= Integer.parseInt(eid);
			ps= con.prepareStatement("delete from employee where eid=?");
			ps.setInt(1,e);
			ps.executeUpdate();
			ps.close();
			ps= con.prepareStatement("delete from achieve where eid=?");
			ps.setInt(1,e);
			ps.executeUpdate();
			ps.close();
			ps=con.prepareStatement("delete from userdetails where eid=?");
			ps.setInt(1,e);
			ps.executeUpdate();
			ps.close();
			con.close();
			out.println("Employee Deleted!");
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
