import java.sql.*;
import java.util.*;

public class Tickets
{
	
	String temp;
	String userId;
	String ch4;
	String busNumber;
	String paymentType;
	String name[];
	String gender[];
	String atemp,dsntemp;
	
	boolean success1,success2;
	boolean success3,success4;
	int noOfTickets;
	int cost;
	int age[];
	int ch5;
	int cForOne;
	int transactionId;
	int dsn[];
	
	Allotment seats[];
	
	Scanner i;
	Scanner s;
	
	boolean success;
	
	PreparedStatement ps=null;
	PreparedStatement ps1=null;
	ResultSet rs=null;
	ResultSet rs1=null;
	Card c;
	Validate v=new Validate();
	
	Tickets(int no,String uid,String bno,Connection con)
	{
		int j;
		noOfTickets=no;
		userId=uid;
		busNumber=bno;
		
		dsn=new int[noOfTickets];
		age=new int[noOfTickets];
		name=new String[noOfTickets];
		gender=new String[noOfTickets];
		
		s=new Scanner(System.in);
		i=new Scanner(System.in);
		
		System.out.println("The Seating Arrangement of Bus "+bno+" is as shown below ");
		System.out.println("     |   |   | #|   | D |");
		System.out.println("     -------------------- ");
		try
		{
			ps=con.prepareStatement("select * from Allotment where BusNumber=? order by SeatNumber");
			ps.setString(1, bno);
			rs=ps.executeQuery();
			for(j=0;j<40;j++)
			{
				if(j==0)
				{
					System.out.format("%3s  | ",j+1);
				}
				if(rs.next())
				{
					if(rs.getInt(3)==(j+1))
					{
						System.out.print(rs.getString(6));
						rs.next();
					}
					else
					{
						rs.previous();
						System.out.print(" ");
					}
				}
				else
				{
					System.out.print(" ");
				}
				System.out.print(" | ");
				if((j+1)%4==0)
				{
					System.out.println((j+1));
					System.out.println("     -------------------- ");
					if(j!=39)
					{
						System.out.format("%3s ",(j+2));
						System.out.print(" | ");
					}
				}
				else if((j+1)%2==0)
				{
					System.out.print("#| ");
				}
			}
			System.out.println();
			ps.close();
			rs.close();
			
			success=false;
			
			do
			{
				System.out.println("Do You Want To Select Seats for "+noOfTickets+" Tickets and Continue Booking (Y/N) ?");
				ch4=s.nextLine();
				if(ch4.equals("n") && ch4.equals("N"))
				{
					success=false;
				}
				else if(ch4.equals("y") || ch4.equals("Y"))
				{
					seats=new Allotment[noOfTickets];
					try
					{
						for(j=0;j<noOfTickets;j++)
						{
							System.out.println("Enter Name Of Passenger "+(j+1));
							name[j]=s.nextLine();
							System.out.println("Enter Age Of Passenger "+(j+1));
							atemp=i.nextLine();
							System.out.println("Enter Gender Of Passenger "+(j+1)+" (M/F)");
							gender[j]=s.nextLine();	
							System.out.println("Enter the Seat Number You Desire for Passenger "+(j+1)+" : ");
							dsntemp=i.nextLine();
							success1=v.vali(name[j], "[A-Za-z]+","Name");
							success2=v.vali(atemp, "[0-9]+","Age");
							if(gender[j].equals("F") || gender[j].equals("f") ||gender[j].equals("M") || gender[j].equals("m"))
							{
								success3=true;
							}
							else
							{
								System.out.println("Enter a Valid Gender");
								success3=false;
							}
							success4=v.vali(atemp, "[0-9][0-9]","Seat Number");
							if(success1 && success2 && success3 && success4)
							{
								age[j]=Integer.parseInt(atemp);
								dsn[j]=Integer.parseInt(dsntemp);
								ps=con.prepareStatement("select * from Allotment where BusNumber=? ");
								ps.setString(1, bno);
								rs=ps.executeQuery();
								while(rs.next())
								{
									if(rs.getInt(3)==dsn[j])
									{
										System.out.println("Sorry The Seat is Already Taken !");
										System.out.println("Select a Proper Seat Number");
										j--;
										rs.next();
									}
								}
							}
							else
							{
								j--;
							}
						}
						
						ps=con.prepareStatement("select Cost from Bus where BusNumber=?");
						ps.setString(1, bno);
						rs=ps.executeQuery();
						rs.next();
						cForOne=rs.getInt(1);
						for(j=0;j<noOfTickets;j++)
						{
							if(age[j]<6)
							{
								System.out.println("Cost For "+name[j]+" Half ");
								cost=cost+(cForOne/2);
							}
							else
							{
								cost=cost+cForOne;
							}
						}
					}
					catch (Exception e) 
					{
						e.printStackTrace();
					}
					try
					{
						do
						{
							System.out.println("Proceed to payment .?");
							ch4=s.nextLine();
							if(ch4.equals("n") && ch4.equals("N"))
							{
								success=false;
							}
							else if(ch4.equals("y") || ch4.equals("Y"))
							{
								success=false;
								do
								{
									System.out.println("Select Your Payment Type : ");
									System.out.println("1.Credit");
									System.out.println("2.Debit");
									System.out.println("3.COD");
									System.out.println("Enter Your Choice : ");
									ch5=i.nextInt();
									if(ch5==1)
									{
										success=true;
										c=new Card();
										paymentType="Credit";
									}
									else if(ch5==2)
									{
										success=true;
										c=new Card();
										paymentType="Debit";
									}
									else if(ch5==3)
									{
										success=true;
										paymentType="COD";
										System.out.println("Cost is : "+cost);
										System.out.println("The Tickets will be Delivered to Your Address !");
										System.out.println();
										
									}
									else
									{
										System.out.println("Enter A Valid Input !");
										success=false;
									}
								}while(!success);			
								
								ps1=con.prepareStatement("select max(TransactionID) from Allotment");
								rs1=ps1.executeQuery();
								rs1.next();
								temp=rs1.getString(1);
								if(temp!=null)
								{
									transactionId=Integer.parseInt(temp);
								}
								transactionId=rs1.getInt(1);
								transactionId++;
								ps1.close();
								rs1.close();
								ps1=con.prepareStatement("update Bus set SeatsAvailable=SeatsAvailable-? where BusNumber=?");
								ps1.setInt(1, noOfTickets);
								ps1.setString(2, bno);
								ps1.executeUpdate();
								ps1.close();
								if(paymentType.equals("COD"))
								{
									ps1=con.prepareStatement("insert into Tickets values(?,?,?,?,?)");
									ps1.setInt(1, transactionId);
									ps1.setString(2, userId);
									ps1.setInt(3, noOfTickets);
									ps1.setInt(4, cost);
									ps1.setString(5, paymentType);
									ps1.executeUpdate();
									ps1.close();
									System.out.println("Transaction ID is : "+transactionId);
									for(j=0;j<noOfTickets;j++)
									{
										new Allotment(dsn[j],bno,age[j],name[j],gender[j],con,transactionId);
									}
									success=false;
								}
								else
								{
									success=c.cardCheck(con,paymentType,cost);
								}
								if(success)
								{
									ps1=con.prepareStatement("insert into Tickets values(?,?,?,?,?)");
									ps1.setInt(1, transactionId);
									ps1.setString(2, userId);
									ps1.setInt(3, noOfTickets);
									ps1.setInt(4, cost);
									ps1.setString(5, paymentType);
									ps1.executeUpdate();
									ps1.close();
									success=false;
									System.out.println("Transaction ID is : "+transactionId);
									System.out.println("Please Note It Down for Future Reference");
									System.out.println("Tickets BOOKED");
									for(j=0;j<noOfTickets;j++)
									{
										new Allotment(dsn[j],bno,age[j],name[j],gender[j],con,transactionId);
									}
								}
								else
								{
									success=false;
									System.out.println("TRANSACTION FAILED due to technical reasons!");
								}
							}
						}while(success);
					}
					catch (Exception e) 
					{
						e.printStackTrace();
					}		
				}
				else
				{
					System.out.println("Enter a Valid Input !");
					success=true;
				}
			}while(success);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	public Tickets(Connection con)
	{
		cost=0;
		success=false;
		String bno,ch,cno,nam;
		int sno,cvn;
		int tid;
		
		s=new Scanner(System.in);
		i=new Scanner(System.in);
		ch="N";
		do
		{
			try
			{
				System.out.println("Enter the Transaction id : ");
				tid=i.nextInt();
				System.out.println("Enter The Bus Number : ");
				bno=s.nextLine();
				System.out.println("Enter The Seat Number : ");
				sno=i.nextInt();
				ps=con.prepareStatement("select * from Allotment where BusNumber=? and SeatNumber=? and transactionID= ? ");
				ps.setInt(3,tid);
				ps.setString(1, bno);
				ps.setInt(2, sno);
				rs=ps.executeQuery( );
				if(rs.next())
				{
					ps1=con.prepareStatement("delete from Allotment where BusNumber=? and SeatNumber=?");
					ps1.setString(1, bno);
					ps1.setInt(2, sno);
					ps1.executeUpdate( );
					ps1.close();
	
					ps1=con.prepareStatement("select cost from Bus where BusNumber=?");
					ps1.setString(1, bno);
					rs1=ps1.executeQuery( );
					rs1.next();
					cost=cost+(rs1.getInt(1)/2);
					ps1.close();
					rs1.close();
					success=true;
				}
				else
				{
					System.out.println("No Such Ticket Found !");
					success=false;
				}
				rs.close();
				ps.close();
				System.out.println("Do You Want To Cancel More Tickets ?");
				ch=s.nextLine();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}while(ch.equals("Y") || ch.equals("y"));
		
			try
			{
				System.out.println("Enter the Card Number to Refund Money ");
				cno=s.nextLine();
				System.out.println("Enter Name on Card : ");
				nam=s.nextLine();
				System.out.println("Enter CVV Number : ");
				cvn=i.nextInt();
				ps=con.prepareStatement("select * from Card where Number=? and Name=? and CVV=?");
				ps.setString(1, cno);
				ps.setString(2, nam);
				ps.setInt(3, cvn);
				rs=ps.executeQuery( );
				if(rs.next())
				{
					ps1=con.prepareStatement("update Card set balance=balance + ?");
					ps1.setInt(1, cost);
					ps1.executeUpdate( );
					rs1.close();
					ps1.close();
					System.out.println("Cancelled !");
				}
				else
				{
					System.out.println("Invalid Card !");
				}
				rs.close();
				ps.close();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
	}
}