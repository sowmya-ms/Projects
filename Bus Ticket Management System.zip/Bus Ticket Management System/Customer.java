import java.sql.*;
import java.util.*;

public class Customer extends User
{
	int ch3,no;
	String address;
	String eMail;
	String bno,notemp;
	boolean success1,success2,success3;
	Validate v=new Validate();
	
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	Customer(String id, String pwd, String nam, String phno, String add, String em,Connection con)
	{
		super(id,nam,pwd,phno);
		address=add;
		eMail=em;
		i=new Scanner(System.in);
		s=new Scanner(System.in);
		System.out.println();
		System.out.println("Hello "+name);
		System.out.println();
		do
		{
			System.out.println("MENU");
			System.out.println("~~~~");
			System.out.println("Choose a choice from the following options");
			System.out.println("1.Book");
			System.out.println("2.Cancel");
			System.out.println("3.View Details");
			System.out.println("4.Logout");
			System.out.println("Enter an Option : ");
			ch3=i.nextInt();
			if(ch3==1)
			{
				success=false;
				book(con);
			}
			else if(ch3==2)
			{
				success=false;
				cancel(con);
			}
			else if(ch3==3)
			{
				view(con);
			}
			else if(ch3==4)
			{
				System.out.println("LOGGED OUT !");
			}
			else
			{
				System.out.println("Enter A Valid Option");
			}
		}
		while(ch3!=4);
	}	
	public void book(Connection con)
	{
		System.out.println("Enter the Number of Tickets : ");
		notemp=s.nextLine();
		System.out.println("Enter Bus Number : ");
		bno=s.nextLine();
		success1=v.vali(bno,"^[A-Za-z][0-9]$","Bus Number");
		success2=v.vali(notemp,"^[0-9]$","Number Of Tickets");
		if(success1 && success2)
		{
			try
			{
				no=Integer.parseInt(notemp);
				ps=con.prepareStatement("select * from Bus where BusNumber= ? ");
				ps.setString(1, bno);
				rs=ps.executeQuery();
				if(rs.next())
				{
					if(rs.getInt(9)>=no)
					{
						System.out.println("Seats are Available !");
						success=true;
					}
					else
					{
						System.out.println("Sorry! Bus DOES NOT have enough seats !");
						System.out.println("Only "+rs.getInt(9)+" Left!");
					}
				}
				else
				{
					System.out.println("Enter A Valid Bus Number");
					System.out.println("Select View To Get Details of Bus !");
				}
				ps.close();
				rs.close();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}	
		if(success)
		{
			new Tickets(no,userId,bno,con);		
		}
	}
	public void view(Connection con)
	{
		String from,to;
		System.out.println("Enter the Starting Point : ");
		from=s.nextLine();
		System.out.println("Enter the Destination Point : ");
		to=s.nextLine();
		success2=v.vali(from,"[a-zA-Z]+","Starting Point");
		success3=v.vali(to,"[a-zA-Z]+","Destination Point");
		if(success2 && success3)
		{
			try
			{
				ps=con.prepareStatement("select * from Bus where FromPoint=? and ToPoint=?");
				ps.setString(1, from);
				ps.setString(2, to);
				rs=ps.executeQuery();
				System.out.format("BusNo. Timing\tDate\t       From\t To\t       Route\t Time Cost  Available ");
				System.out.println();
				while(rs.next())
				{
					System.out.format("%3s %10s %11s %11s %11s %11s %3d %6d %4d",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getInt(7),rs.getInt(8),rs.getInt(9));
					System.out.println();
				}
				ps.close();
				rs.close();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
	}
	public void cancel(Connection con)
	{
		new Tickets(con);
		
	}
}
