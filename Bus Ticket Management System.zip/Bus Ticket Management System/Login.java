import java.sql.*;
import java.util.*;
public class Login 
{
	public static void main(String args[])
	{
		String id,pwd,name,phno,add,em;
		int ch1,times,idn,ch3=0;
		String ch2;
		boolean success1=false,success2=false;
		boolean success3=false,success4=false;
		times=0;
		
		Connection con=null; 
		PreparedStatement ps=null;
		ResultSet rs=null;
		Validate v=new Validate();
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/zoho";
			con=DriverManager.getConnection(URL,"root","admin");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		Scanner s=new Scanner(System.in);
		Scanner i=new Scanner(System.in);
		
		System.out.println("WELCOME TO SOWMYA TRAVELS");
		System.out.println("~~~~~~~ ~~ ~~~~~~ ~~~~~~~");
		
		do
		{
			System.out.println("MENU");
			System.out.println("~~~~");
			System.out.println("Select an Option from the following");
			System.out.println("1.New User");
			System.out.println("2.Exsiting User");
			System.out.println("3.Admin");
			System.out.println("4.Exit");
			System.out.println("Enter A Option : ");
			
			ch1=i.nextInt();
		
			if(ch1==1)
			{
				idn=0;
				System.out.println("Welcome New User!");
				do
				{
					success1=false;
					System.out.println("Enter your Name : ");
					name=s.nextLine();
					System.out.println("Enter your Address : ");
					add=s.nextLine();
					System.out.println("Enter your Password : ");
					pwd=s.nextLine();
					System.out.println("Enter your Mobile Number : ");
					phno=s.nextLine();
					System.out.println("Enter your email : ");
					em=s.nextLine();
					success2=v.vali(name,"^[A-Za-z]+$","Name");
					success3=v.vali(phno,"^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]$","Phone Number");
					success4=v.vali(em,"[A-Za-z0-9]+@[A-Z0-9.-]+[/.[A-Z]]*$","E-Mail Id");
					try
					{
						ps=con.prepareStatement("select max(UserID) from User ");
						rs=ps.executeQuery();
						rs.next();
						idn=Integer.parseInt(rs.getString(1));
						rs.close();
						ps.close();
					}
					catch (Exception e) 
					{
						e.printStackTrace();
					}
					idn++;
					id=Integer.toString(idn);
					
					if(success2 && success3 && success4)
					{
						success1=false;
						try
						{
							ps=con.prepareStatement("insert into User values(?,?,?,?)");
							ps.setString(1, id);
							ps.setString(2, pwd);
							ps.setString(3, name);
							ps.setString(4, phno);
							ps.executeUpdate();
							ps.close();
							ps=con.prepareStatement("insert into Customer values(?,?,?)");
							ps.setString(1, id);
							ps.setString(2, add);
							ps.setString(3, em);
							ps.executeUpdate();
							ps.close();
							System.out.println("The User ID Alloted for You is : "+ id);
							System.out.println("Please NOTE IT DOWN for Future Reference ! "); 
							System.out.println();
							ch3=2;
						}
						catch (Exception e) 
						{
							e.printStackTrace();
						}
					}
					else
					{
						System.out.println("Do You Want To Try again ? "); 
						ch2=s.nextLine();
						if(ch2.equals("Y") || ch2.equals("y"))
						{
							success1=true;
						}
						else
						{
							success1=false;
						}
					}
					
				}while(success1);
				
			}
			else if(ch1==2 || ch3==2)
			{
				System.out.println();
				System.out.println("LOGIN TO CONTINUE !");
				System.out.println("~~~~~ ~~ ~~~~~~~~ ~");
				do
				{
					success1=false;
					System.out.println("Enter Your User ID : ");
					id=s.nextLine();
					System.out.println("Enter Your Password : ");
					pwd=s.nextLine();
					success1=v.vali(id,"^[0-9][0-9][0-9]$"," User Id");
					if(success1)
					{
						try
						{
							ps=con.prepareStatement("select * from User where UserID= ? and Password= ?");
							ps.setString(1, id);
							ps.setString(2, pwd);
							rs=ps.executeQuery();
							if(rs.next())
							{	
								times=0;
								name=rs.getString(3);
								phno=rs.getString(4);
								ps.close();
								rs.close();
								ps=con.prepareStatement("select * from Customer where UserID= ?");
								ps.setString(1, id);
								rs=ps.executeQuery();
								rs.next();
								add=rs.getString(2);
								em=rs.getString(3);
								ps.close();
								rs.close();
								new Customer(id,pwd,name,phno,add,em,con);
								success1=false;
							}
							else
							{
								System.out.println("Enter a valid ID and Password!");
								success2=false;
								times++;
								System.out.println("Forgot Password ( Y/N )?");
								ch2=s.nextLine();
								if(ch2.equals("Y") || ch2.equals("y"))
								{
									ch3=1;
									success1=false;
								}				
							}
						}
						catch (Exception e) 
						{
							e.printStackTrace();
						}
					}
					else
					{
						times++;
						success1=false;
					}	
				}while(success1);
				if(times>=3)
				{
					System.out.println("You Have exceeded the maximum limit!");
					ch1=4;
				}
			}
			else if(ch1==3)
			{
				System.out.println("Enter Your Admin ID : ");
				id=s.nextLine();
				System.out.println("Enter Your Password : ");
				pwd=s.nextLine();
				if(id.equals("Admin") && pwd.equals("Admin123"))
				{
					new Admin(id,"Admin",pwd,"1234567890",con);	
				}
				else
				{
					System.out.println("Invalid Admin");
				}
			}
			else if(ch1==4)
			{
				try	
				{
					con.close();
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				s.close();
				i.close();
			}
			else if(ch1>4)
			{
				System.out.println("Enter a Valid Choice! ");
			}
			if(ch3==1)
			{
				System.out.println("Enter your Name : ");
				name=s.nextLine();
				System.out.println("Enter your Phone Number : ");
				phno=s.nextLine();
				success2=v.vali(name,"^[A-Za-z]*$","Name");
				success3=v.vali(phno,"^[0-9]{10}","Phone Number");
				
				if(success2 && success3)
				{
					pwd="";
					try
					{
						ps=con.prepareStatement("select Password from User where Name=? and PhoneNumber=? ");
						ps.setString(1,name);
						ps.setString(2,phno);
						rs=ps.executeQuery();
						if(rs.next())
						{
							System.out.println("Your Password is : "+rs.getString(1));
						}
						else
						{
							success1=false;
							System.out.println("Enter User details! ");
						}
						rs.close();
						ps.close();	
					}
					catch (Exception e) 
					{
						e.printStackTrace();
					}
				}
			}
		}while(ch1!=4);
	}
}
