import java.util.Scanner;

public class User
{
	Scanner i,s;
	String userId;
	String name;
	String password;
	String phoneNumber;
	boolean success;
	
	public User(String id, String nam, String pwd, String phno)
	{
		userId=id;
		name=nam;
		password=pwd;
		phoneNumber=phno;
		
	}
}
