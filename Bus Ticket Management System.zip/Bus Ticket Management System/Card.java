import java.sql.*;
import java.util.*;

public class Card
{
	PreparedStatement ps1;
	ResultSet rs1;
	Scanner s,i;
	String number;
	String name;
	String type,cvnt;
	int balance;
	int cvn;
	Validate v= new Validate();
	boolean success,success1;
	boolean success2,success3;
	
	public boolean cardCheck(Connection con,String pt,int amt)
	{
		success=false;
		s=new Scanner(System.in);
		i=new Scanner(System.in);
		System.out.println("Enter Card Number : ");
		number=s.nextLine();
		System.out.println("Enter Name on Card : ");
		name=s.nextLine();
		System.out.println("Enter CVV Number : ");
		cvnt=i.nextLine();
		success1=v.vali(number,"^[0-9]{16}$","Card Number");
		success2=v.vali(name,"^[a-zA-Z]+$","Name");
		success3=v.vali(cvnt,"^[0-9][0-9][0-9]$","CVN Number");
		if(success1 && success2 && success3)
		{
			cvn=Integer.parseInt(cvnt);
			if(verify(con,pt))
			{
				if(pay(con,amt))
				{
					success=true;
				}
				else
				{
					System.out.println("Transaction Failed due to Technical Reasons!");
					success=false;
				}
			}
			else
			{
				System.out.println("Invalid Card Number! Transaction Failed !");
				success=false;
			}
		}
		else
		{
			success=cardCheck(con,pt,amt);
		}
		return success;
	}
	public boolean verify(Connection con,String pt)
	{
		boolean success=false;
		try
		{
			ps1=con.prepareStatement("select * from Card where Number=? and Name=? and CVV=? and Type=?");
			ps1.setString(1, number);
			ps1.setString(2, name);
			ps1.setInt(3, cvn);
			ps1.setString(4, pt);
			rs1=ps1.executeQuery();
			success=rs1.next();
			ps1.close();
			rs1.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return success;
	}
	public boolean pay(Connection con,int amt)
	{
		boolean success=false;
		try
		{
			ps1=con.prepareStatement("select balance from Card where Number=?");
			ps1.setString(1, number);
			rs1=ps1.executeQuery();
			rs1.next();
			balance=rs1.getInt(1);
			ps1.close();
			rs1.close();
			if((balance-amt)>500)
			{
				balance=balance-amt;
				ps1=con.prepareStatement("update Card set balance=? where Number=?");
				ps1.setInt(1, balance);
				ps1.setString(2, number);
				ps1.executeUpdate();
				ps1.close();
				success= true;	
			}
			else
			{	
				success= false;
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return success;
	}
}