import java.sql.*;

public class Allotment
{
		PreparedStatement ps1;
		
		Allotment(int seat,String bno,int age,String name,String gender, Connection con,int tid)
		{
			try
			{
				ps1=con.prepareStatement("insert into allotment values (?,?,?,?,?,?)");
				ps1.setInt(1, tid);
				ps1.setString(2, bno);
				ps1.setInt(3, seat);
				ps1.setString(4, name);
				ps1.setInt(5, age);
				ps1.setString(6, gender);
				ps1.executeUpdate();
				ps1.close();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
		}
	
}