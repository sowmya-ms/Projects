
public class Validate 
{
	public boolean vali(String tocheck,String re,String msg)
	{
		boolean success;
		if(tocheck.matches(re))
		{
			success=true;
		}
		else
		{
			success=false;
			System.out.println("Enter A Valid "+msg);
		}
		return success; 
	}
}
