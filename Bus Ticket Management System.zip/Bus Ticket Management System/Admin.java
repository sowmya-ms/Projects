import java.sql.*;
import java.util.*;


public class Admin extends User
{
	int ch1,ch2,ch3,newValI;
	String bno,timing,date,fp,tp,route,toUpdate,newVal,time;
	String seats,cost;
	boolean success1,success2,success3,success4;
	boolean success5,success6,success7,success8;
	boolean success9;
	Validate v=new Validate();
	Scanner s,i;
	
	PreparedStatement ps3=null;
	ResultSet rs3=null;
	
	Admin(String id, String nam, String pwd, String phno,Connection con)
	{
		super(id,nam,pwd,phno);		
		s=new Scanner(System.in);
		i=new Scanner(System.in);
		
		System.out.println("Welcome Administrator !");
		System.out.println("~~~~~~~ ~~~~~~~~~~~~~ ~");
		do
		{	
			System.out.println("MENU");
			System.out.println("1.Manage Bus");
			System.out.println("2.List All Transactions");
			System.out.println("3.List All Allotments");
			System.out.println("4.Exit");
			System.out.println("Select Your Choice : ");
			ch1=i.nextInt();
			if(ch1==1)
			{
				try
				{
					System.out.println("1.Add Bus");
					System.out.println("2.Delete Bus");
					System.out.println("3.Update Bus");
					System.out.println("4.View Bus");
					System.out.println("5.View All Buses");
					System.out.println("6.Exit");
					System.out.println("Select Your Choice : ");
					ch2=i.nextInt();
					if(ch2==1)
					{
						addBus(con);
					}
					else if(ch2==2)
					{
						delbus(con);
					}
					else if(ch2==3)
					{
						manageBus(con);
					}
					else if(ch2==4)
					{
						System.out.println("Enter the Bus Number : ");
						bno=s.nextLine();
						success1=v.vali(bno,"^[A-Za-z][0-9]$","Bus Number");
						if(success1)
						{
							ps3=con.prepareStatement("select * from Bus where BusNumber=?");
							ps3.setString(1, bno);
							rs3=ps3.executeQuery();
							System.out.format("BusNo. Timing\tDate\t       From\t To\t       Route\t Time Cost  Available ");
							System.out.println();
							while(rs3.next())
							{
								System.out.format("%3s %10s %11s %11s %11s %11s %3d %6d %4d",rs3.getString(1),rs3.getString(2),rs3.getString(3),rs3.getString(4),rs3.getString(5),rs3.getString(6),rs3.getInt(7),rs3.getInt(8),rs3.getInt(9));
								System.out.println();
							}
							rs3.close();
							ps3.close();
					
						}
					}
					else if(ch2==5)
					{
						ps3=con.prepareStatement("select * from Bus");
						rs3=ps3.executeQuery();
						System.out.format("BusNo. Timing\tDate\t       From\t To\t       Route\t Time Cost  Available ");
						System.out.println();
						while(rs3.next())
						{
							System.out.format("%3s %10s %11s %11s %11s %11s %3d %6d %4d",rs3.getString(1),rs3.getString(2),rs3.getString(3),rs3.getString(4),rs3.getString(5),rs3.getString(6),rs3.getInt(7),rs3.getInt(8),rs3.getInt(9));
							System.out.println();
						}
						rs3.close();
						ps3.close();
					}
					else if(ch2==6)
					{
						
					}
					else
					{
						System.out.println("Enter A Valid Input !");
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else if(ch1==2)
			{
				try
				{
					ps3=con.prepareStatement("select * from Tickets");
					rs3=ps3.executeQuery();
					System.out.println("TransactionID\tUserID\tNo. of Tickets\tCost\tPaymentType");
					while(rs3.next())
					{
						System.out.format("%13d %8s %12s %7s %15s ",rs3.getInt(1),rs3.getString(2),rs3.getInt(3),rs3.getInt(4),rs3.getString(5));
						System.out.println();
					}
					rs3.close();
					ps3.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else if(ch1==3)
			{
				System.out.println("Enter the Bus Number : ");
				bno=s.nextLine();
				success1=v.vali(bno,"^[A-Za-z][0-9]$","Bus Number");
				if(success1)
				{
					try
					{
						ps3=con.prepareStatement("select * from Allotment where BusNumber=?");
						ps3.setString(1, bno);
						rs3=ps3.executeQuery();
						System.out.println("TransactionID\tBus No.\tSeat No.\tName\tAge\tGender");
						while(rs3.next())
						{
							System.out.format("%13d %8s %8d %12s %6d %10s ",rs3.getInt(1),rs3.getString(2),rs3.getInt(3),rs3.getString(4),rs3.getInt(5),rs3.getString(6));
							System.out.println();
						}
						rs3.close();
						ps3.close();
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
			}
			else if(ch1==4)
			{
				
			}
			else
			{
				System.out.println("Enter A Valid Input !");
			}
		}while(ch1!=4);
	}
	void manageBus(Connection conn)
	{
		try
		{
			System.out.println("Enter the Bus Number : ");
			bno=s.nextLine();
			System.out.println("Enter the Data To Modify");
			System.out.println("1.Timing");
			System.out.println("2.Date");
			System.out.println("3.Starting Point");
			System.out.println("4.Destination Point");
			System.out.println("5.Route");
			System.out.println("6.Journey Time");
			System.out.println("7.Cost");
			System.out.println("8.Seats");
			System.out.println("9.Exit");
			System.out.println("Enter Your Choice : ");
			ch3=i.nextInt();
			if(ch3>0 && ch3 <6)
			{
				System.out.println("Enter New Value : ");
				newVal=s.nextLine();
				if(ch3==1)
				{
					success1=v.vali(newVal,"^[0-9][0-9].[0-9][0-9] [a-zA-Z][a-zA-Z]$","Timing");
					toUpdate="Timing";
				}
				else if(ch3==2)
				{
					success1=v.vali(newVal,"[0-9][0-9].[0-9][0-9].[0-9][0-9][0-9][0-9]$","Date");
					toUpdate="Date";
				}
				else if(ch3==3)
				{
					success1=v.vali(newVal,"^[a-zA-Z]+$","Starting Point");
					toUpdate="FromPoint";
				}
				else if(ch3==4)
				{
					success1=v.vali(newVal,"^[a-zA-Z]+$","Destination Point");
					toUpdate="ToPoint";
				}
				else if(ch3==5)
				{
					success1=v.vali(newVal,"^[a-zA-Z]+$","Route");
					toUpdate="Route";
				}
				ps3=conn.prepareStatement("Update Bus set "+toUpdate+" = ? where BusNumber= ? ");
				ps3.setString(1, newVal);
				ps3.setString(2, bno);
				ps3.executeUpdate();
				ps3.close();
				System.out.println("Bus Updated !");
			}
			else if(ch3>5 && ch3<9)
			{
				System.out.println("Enter New Value : ");
				newVal=s.nextLine();
				if(ch3==6)
				{
					success1=v.vali(newVal,"^[0-9]+$","Journey Time");
					toUpdate="Journey";
				}
				else if(ch3==7)
				{
					success1=v.vali(newVal,"^[0-9]+$","Cost");
					toUpdate="Cost";
				}
				else if(ch3==8) 
				{
					toUpdate="SeatsAvailable";
					success1=v.vali(newVal,"^[0-9]+$","Total Seats");
				}
				ps3=conn.prepareStatement("Update Bus set "+toUpdate+" = ? where BusNumber= ? ");
				ps3.setString(2, bno);
				ps3.setInt(1, Integer.parseInt(newVal));
				ps3.executeUpdate();
				ps3.close();
				System.out.println("Bus Updated !");
			}
			else
			{
				System.out.println("Enter A Valid Choice !");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void delbus(Connection con)
	{
		System.out.println("Enter the Bus Number : ");
		bno=s.nextLine();
		success1=v.vali(bno,"^[A-Za-z][0-9]$","Bus Number");
		if(success1)
		{
			try
			{
				ps3=con.prepareStatement("delete from Bus where BusNumber=?");
				ps3.setString(1, bno);
				ps3.executeUpdate();
				ps3.close();
				System.out.println("Bus Deleted !");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	public void addBus(Connection con)
	{
		
		System.out.println("Enter the Bus Number : ");
		bno=s.nextLine();
		System.out.println("Enter the Timing : ");
		timing=s.nextLine();
		System.out.println("Enter the Date : ");
		date=s.nextLine();
		System.out.println("Enter the Starting Point : ");
		fp=s.nextLine();
		System.out.println("Enter the Destination Point : ");
		tp=s.nextLine();
		System.out.println("Enter the Route : ");
		route=s.nextLine();
		System.out.println("Enter the Journey Time : ");
		time=s.nextLine();
		System.out.println("Enter the Cost per Seat : ");
		cost=s.nextLine();
		System.out.println("Enter the Total Seats : ");
		seats=s.nextLine();
		success1=v.vali(bno,"^[A-Za-z][0-9]$","Bus Number");
		success2=v.vali(timing,"^[0-9][0-9].[0-9][0-9] [a-zA-Z][a-zA-Z]$","Timing");
		success3=v.vali(date,"[0-9][0-9].[0-9][0-9].[0-9][0-9][0-9][0-9]$","Date");
		success4=v.vali(fp,"^[a-zA-Z]+$","Starting Point");
		success5=v.vali(tp,"^[a-zA-Z]+$","Destination Point");
		success6=v.vali(route,"^[a-zA-Z]+$","Route");
		success7=v.vali(time,"^[0-9]+$","Journey Time");
		success8=v.vali(cost,"^[0-9]+$","Cost");
		success9=v.vali(seats,"^[0-9]+$","Total Seats");
		if(success1 && success2 && success3 && success4 && success5 && success6 && success7 && success8 && success9)
		{
			try
			{
				ps3=con.prepareStatement("insert into Bus values(?,?,?,?,?,?,?,?,?)");
				ps3.setString(1, bno);
				ps3.setString(2, timing);
				ps3.setString(3, date);
				ps3.setString(4, fp);
				ps3.setString(5, tp);
				ps3.setString(6, route);
				ps3.setInt(7, Integer.parseInt(time));
				ps3.setInt(8, Integer.parseInt(cost));
				ps3.setInt(9, Integer.parseInt(seats));
				ps3.executeUpdate();
				ps3.close();
				System.out.println("Bus Added !");
				System.out.println();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}