sz = [258,310];
numTrain = 5;
videoname='Sample Video 2.avi';
v=VideoReader(videoname);
sortframe(v);
trainData = zeros(numTrain,prod(sz));
for i=1:numTrain
    img = imread( sprintf('Train/img%d.jpg',i) );
     for j=1:numTrain
        trainData(i,j) = img(j);
    end
end
numTest = v.NumberOfFrames;
testData = zeros(numTest,prod(sz));
for i=1:numTest
    img = imread( sprintf('Test/img%d.jpg',i) );
    for j=1:numTest
        testData(i,j) = img(j);
    end
end
group = [1;2;3;4;5];
class = knnclassify(testData, trainData, group,5,'cityblock','nearest');
x=sprintf('Frame        | Scene        | Class  ');
disp(x);
counter=1;
prevclass=class(1);
for i=1:numTest
    if((prevclass)~=(class(i)))
        counter=counter+1;
    end
    x=sprintf('Frame%d      | Scene%d      | Class%d',i,counter,class(i));
    disp(x);
    prevclass=class(i);
end