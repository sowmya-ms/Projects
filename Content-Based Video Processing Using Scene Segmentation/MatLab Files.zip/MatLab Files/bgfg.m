vid = 'Sample Video 1.avi';
readerobj = VideoReader(vid);
bg =  read(readerobj,1);
for k=1: readerobj.NumberOfFrames
    if(k~=readerobj.NumberOfFrames)
        J=read(readerobj,k+1);
        filename=strcat('Bg Subracted/bgdetected',num2str(k),'.jpg');
        imgco(bg,J,filename);
    end
end
startframe=1;
counter=1;
prevflag=0;
for k=1:readerobj.NumberOfFrames-1
   filename=strcat('Bg Subracted/bgdetected',num2str(k),'.jpg');
   black=count(filename);
   if(k>1)
           prevflag=flag;
   end
   if(black==100)
       flag=1;
   else
        flag=0;
   end
   if((prevflag==(flag+1))||(flag==(prevflag+1)))
      endframe=k;
      X=sprintf('Scene %d : Frame %d to %d',counter,startframe,endframe);
      disp(X);
      startframe=k+1;
      counter=counter+1;
   end        
end    
endframe=readerobj.NumberOfFrames;
X=sprintf('Scene %d : Frame %d to %d',counter,startframe,endframe);
disp(X);