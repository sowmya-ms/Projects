function [ percentBlackPixel ] = count( filename )
img = imread(filename);
numTotalPixel = size(img,1) * size(img, 2);
numBlackPixel = sum(img(:)==0);
percentBlackPixel = numBlackPixel / numTotalPixel * 100;
end