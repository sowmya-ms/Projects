vid = 'Sample Video 1.avi';
readerobj = VideoReader(vid);
X=zeros(1,1799);
for k=1:  readerobj.NumberOfFrames
    I=read(readerobj,k);
    if(k~= readerobj.NumberOfFrames)
        J=read(readerobj,k+1);
        sss=absdif(I,J);
        X(k)=sss;
    end
end
mean=mean2(X);
std=std2(X);
threshold=std+mean*10;
startframe=1;
counter=1;
for k=1: readerobj.NumberOfFrames
    I =  read(readerobj,k);
    if(k~=readerobj.NumberOfFrames)
        J=   read(readerobj,k+1);
        sss=absdif(I,J);
        if(sss>threshold)
            endframe=k;
            filename=strcat('Keyframes/img',num2str(k),'.jpg');
            imwrite(J,filename);
            X=sprintf('Scene %d : Frame %d to %d',counter,startframe,endframe);
            disp(X);
            startframe=k+1;
            counter=counter+1;
        end
    end
end
X=sprintf('Scene %d : Frame %d to %d',counter,startframe,readerobj.NumberOfFrames);
disp(X);