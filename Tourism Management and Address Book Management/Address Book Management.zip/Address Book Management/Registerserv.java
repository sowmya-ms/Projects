

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Registerserv
 */
@WebServlet("/Registerserv")
public class Registerserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PreparedStatement ps=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registerserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		ps=null;
		
		PrintWriter out=response.getWriter();
//		out.println("success");
		HttpSession ses=request.getSession();
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/Phase1";
			PreparedStatement ps=null;
			Connection con=DriverManager.getConnection(URL,"root","admin");
			out.println("success1");

			String uid=request.getParameter("uid");
			String pwd=request.getParameter("password");			
			String name=request.getParameter("name");
			String desig=request.getParameter("desig");
			String addr1=request.getParameter("addr1");
			String addr2=request.getParameter("addr2");
			String email=request.getParameter("eid");
			String city=request.getParameter("city");
			String state=request.getParameter("state");
			ses.setAttribute("uid", uid);
			
			int u=Integer.parseInt(uid);
			
			
			out.println("success2");

			ps=con.prepareStatement("insert into user values(?,?)");
			ps.setInt(1,u);
			ps.setString(2, pwd);
			ps.executeUpdate();
			ps.close();
			out.println("success5");

			ps=con.prepareStatement("insert into addressbook values(?,?,?,?,?,?,?,?)");
			ps.setInt(1,u);
			ps.setString(2, name);
			ps.setString(3,desig);
			ps.setString(4,addr1);
			ps.setString(5,addr2);
			ps.setString(6, email);
			ps.setString(7,city);
			ps.setString(8,state);
			out.println("success3");

			ps.executeUpdate();
			ps.close();
			out.println("success4");

			
			RequestDispatcher rd=request.getRequestDispatcher("FindPage.html");
			rd.forward(request,response);
						
			ps.close();
			con.close();
			//out.println("Inserted!");
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			//e.printStackTrace();
			out.println(e);
		}

	}

}
