

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Deleteserv
 */
@WebServlet("/Deleteserv")
public class Deleteserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Deleteserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession ses=request.getSession();
		String uid=(String) ses.getAttribute("uid");
		int u=Integer.parseInt(uid);
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/Phase1";
			PreparedStatement ps=null;
			Connection con=DriverManager.getConnection(URL,"root","admin");
			String email;
			email=request.getParameter("eid");
			
			ps=con.prepareStatement("delete from addressbook where email=? and uid=?");
			//out.println(email);
			ps.setString(1,email);
			ps.setInt(2, u);
			
			ps.executeUpdate();
			out.println("Deleted!");
			con.close();
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
