

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Createserv
 */
@WebServlet("/Createserv")
public class Createserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement ps;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Createserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		ps=null;
		PrintWriter out=response.getWriter();
		HttpSession ses=request.getSession();
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/Phase1";
			PreparedStatement ps=null;
			Connection con=DriverManager.getConnection(URL,"root","admin");
			String uid=(String) ses.getAttribute("uid");
			int u=Integer.parseInt(uid);
			String fname=request.getParameter("fname");
			String desig=request.getParameter("desig");
			String add1=request.getParameter("add1");
			String add2=request.getParameter("add2");
			String email=request.getParameter("eid");
			String city=request.getParameter("city");
			String state=request.getParameter("state");
			ps=con.prepareStatement("insert into addressbook values(?,?,?,?,?,?,?,?)");
			ps.setInt(1,u);
			ps.setString(2, fname);
			ps.setString(3,desig);
			ps.setString(4,add1);
			ps.setString(5,add2);
			ps.setString(6, email);
			ps.setString(7,city);
			ps.setString(8,state);
			ps.executeUpdate();
			ps.close();
			con.close();
			out.println("Inserted!");
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
