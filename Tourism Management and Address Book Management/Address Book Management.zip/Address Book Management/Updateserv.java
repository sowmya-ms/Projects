

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.Statement;




import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Updateserv
 */
@WebServlet("/Updateserv")
public class Updateserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updateserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession ses=request.getSession();
		String uid=(String) ses.getAttribute("uid");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/Phase1";
			Connection con=DriverManager.getConnection(URL,"root","admin");
			PreparedStatement ps=null;
			//ResultSet rs=null;
			String email=request.getParameter("eid");
			String fname=request.getParameter("fname");
			String desig=request.getParameter("desig");
			String add1=request.getParameter("add1");
			String add2=request.getParameter("add2");
			String city=request.getParameter("city");
			String state=request.getParameter("state");
			ps=con.prepareStatement("update addressbook set fname=?,desig=?,add1=?,add2=?, city=?, state=? where email=? and uid=?");
			ps.setString(1, fname);
			ps.setString(2,desig);
			ps.setString(3,add1);
			ps.setString(4,add2);
			ps.setString(7,email);
			ps.setString(5,city);
			ps.setString(6,state);
			int u=Integer.parseInt(uid);
			ps.setInt(8, u);
			ps.executeUpdate();
			ps.close();
			out.println("Updated!");
			con.close();
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
