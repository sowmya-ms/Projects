

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Readserv
 */
@WebServlet("/Readserv")
public class Readserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Readserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession ses=request.getSession();
		String uid=(String) ses.getAttribute("uid");
		int u=Integer.parseInt(uid);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/Phase1";
			Connection con=DriverManager.getConnection(URL,"root","admin");
			PreparedStatement ps=null;
			ResultSet rs=null;
			String email=request.getParameter("eid");
			ps=con.prepareStatement("select * from addressbook where email=? and uid=?");
			ps.setString(1, email);
			ps.setInt(2, u);
			rs=ps.executeQuery();
			out.println("<table border='3'><tr><td>Name</td><td>Desig</td><td>Add1</td><td>Add2</td><td>Email</td><td>City</td><td>State</td></tr>");
			while(rs.next())
			{
				out.println("<tr><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getString(7)+"</td><td>"+rs.getString(8)+"</td></tr>");
			}
			out.println("</table>");
			con.close();
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
